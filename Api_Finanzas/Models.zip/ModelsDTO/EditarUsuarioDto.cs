﻿namespace Api_Finanzas.ModelsDTO
{
    public class EditarUsuarioDto
    {
        public string Nombre { get; set; }
        public string Rol { get; set; }
        public string Contrasena { get; set; }
    }
}
