﻿namespace Api_Finanzas.Services
{
    public static class SesionActual
    {
        public static string Email { get; set; }
    }
}