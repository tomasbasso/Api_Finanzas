﻿namespace Api_Finanzas.ModelsDTO
{
    public class LoginDto
    {
        public string Email { get; set; }
        public string Contrasena { get; set; }
    }
}
