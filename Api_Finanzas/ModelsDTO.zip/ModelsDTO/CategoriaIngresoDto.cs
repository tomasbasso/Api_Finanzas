﻿namespace Api_Finanzas.ModelsDTO
{
    public class CategoriaIngresoDto
    {
     
        public int CategoriaIngresoId { get; set; }
        public string Nombre { get; set; }
        public int? UsuarioId { get; set; }
    }
}
