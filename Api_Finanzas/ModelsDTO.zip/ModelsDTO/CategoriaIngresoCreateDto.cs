﻿namespace Api_Finanzas.ModelsDTO
{
    public class CategoriaIngresoCreateDto
    {
        public string Nombre { get; set; }
        //public int? UsuarioId { get; set; }
    }
}
