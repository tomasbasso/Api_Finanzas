﻿namespace Api_Finanzas.ModelsDTO
{
    public class CategoriaGastoDto
    {
        public int CategoriaGastoId { get; set; }
        public string Nombre { get; set; }
        public int? UsuarioId { get; set; }
    }
}
