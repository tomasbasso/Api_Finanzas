﻿namespace Api_Finanzas.ModelsDTO
{
    public class CrearCategoriaGastoDto
    {
        public string Nombre { get; set; }
        //public int? UsuarioId { get; set; }
    }
}
