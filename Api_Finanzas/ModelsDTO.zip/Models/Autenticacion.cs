﻿namespace Api_Finanzas.Models
{
    public class Autenticacion
    {
    }
}
